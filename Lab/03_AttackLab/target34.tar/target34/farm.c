/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_424(unsigned x)
{
    return x + 3281014951U;
}

unsigned getval_130()
{
    return 259441624U;
}

unsigned addval_232(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_104()
{
    return 3284633928U;
}

unsigned addval_489(unsigned x)
{
    return x + 3347138779U;
}

void setval_484(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_375(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_499(unsigned x)
{
    return x + 3284633930U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_265()
{
    return 2429978973U;
}

unsigned getval_350()
{
    return 3536109961U;
}

void setval_200(unsigned *p)
{
    *p = 3252717896U;
}

void setval_339(unsigned *p)
{
    *p = 3373845129U;
}

void setval_390(unsigned *p)
{
    *p = 3674789505U;
}

unsigned getval_108()
{
    return 3269495112U;
}

unsigned getval_332()
{
    return 3286272328U;
}

unsigned addval_235(unsigned x)
{
    return x + 3247039434U;
}

unsigned addval_154(unsigned x)
{
    return x + 3222853257U;
}

unsigned addval_374(unsigned x)
{
    return x + 3221804683U;
}

unsigned getval_465()
{
    return 3524837769U;
}

void setval_300(unsigned *p)
{
    *p = 3737305481U;
}

unsigned addval_389(unsigned x)
{
    return x + 3531921037U;
}

unsigned addval_352(unsigned x)
{
    return x + 1942211209U;
}

void setval_233(unsigned *p)
{
    *p = 3353381192U;
}

void setval_471(unsigned *p)
{
    *p = 3523791369U;
}

unsigned addval_393(unsigned x)
{
    return x + 3380139657U;
}

void setval_417(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_451()
{
    return 3281046153U;
}

void setval_480(unsigned *p)
{
    *p = 3677405577U;
}

unsigned addval_242(unsigned x)
{
    return x + 3525888649U;
}

unsigned getval_475()
{
    return 3523791513U;
}

unsigned getval_435()
{
    return 3375942153U;
}

void setval_256(unsigned *p)
{
    *p = 3767094290U;
}

void setval_481(unsigned *p)
{
    *p = 2445969912U;
}

unsigned getval_228()
{
    return 3768141960U;
}

unsigned addval_149(unsigned x)
{
    return x + 3527983497U;
}

unsigned addval_397(unsigned x)
{
    return x + 3284238609U;
}

void setval_421(unsigned *p)
{
    *p = 3601457237U;
}

unsigned getval_196()
{
    return 3380926089U;
}

unsigned getval_174()
{
    return 3284240660U;
}

unsigned getval_262()
{
    return 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
